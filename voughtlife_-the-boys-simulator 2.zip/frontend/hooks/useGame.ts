import { useState, useCallback, useEffect } from 'react';
import { GameState, ChoiceEffects, StateChanges, Job, Asset, Stock, CompoundVStatus, GameEvent, Power } from '../types';
import { INITIAL_STATE, COMPOUND_V_PRICES, AVAILABLE_JOBS, BUYABLE_ASSETS, POWER_TEMPLATES } from '../constants';
import { generateYearlyEvents } from '../services/ai';

const SAVE_KEY = 'voughtlife_save_v2';

const MONTHS: Record<string, number> = {
  "ocak": 1, "şubat": 2, "mart": 3, "nisan": 4, "mayıs": 5, "haziran": 6,
  "temmuz": 7, "ağustos": 8, "eylül": 9, "ekim": 10, "kasım": 11, "aralık": 12
};

function parseDate(dateStr?: string) {
  if (!dateStr) return { day: 0, month: 0 };
  const parts = dateStr.toLowerCase().trim().split(' ');
  if (parts.length < 2) return { day: parseInt(parts[0]) || 0, month: 0 };
  const day = parseInt(parts[0]) || 0;
  const month = MONTHS[parts[1]] || 0;
  return { day, month };
}

function sortEventsByDate(events?: GameEvent[]): GameEvent[] {
  if (!Array.isArray(events)) return [];
  return [...events].sort((a, b) => {
    const dateA = parseDate(a.date);
    const dateB = parseDate(b.date);
    if (dateA.month !== dateB.month) return dateA.month - dateB.month;
    return dateA.day - dateB.day;
  });
}

function generateRandomPowers(): Power[] {
  const count = Math.random() > 0.8 ? 2 : 1; // 20% chance for 2 powers
  const shuffled = [...POWER_TEMPLATES].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count).map(p => ({ ...p, id: 'p_' + Date.now() + Math.random() }));
}

export function useGame() {
  const [state, setState] = useState<GameState>(() => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Failed to load save game", e);
    }
    return INITIAL_STATE;
  });
  
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  }, [state]);

  const updateStats = useCallback((effects?: ChoiceEffects, stateChanges?: StateChanges) => {
    setState(prev => {
      const newStats = { ...prev.stats };
      
      if (effects) {
        if (typeof effects.health === 'number') newStats.health = Math.max(0, Math.min(100, newStats.health + effects.health));
        if (typeof effects.fame === 'number') newStats.fame = Math.max(0, Math.min(100, newStats.fame + effects.fame));
        if (typeof effects.power === 'number') newStats.power = Math.max(0, Math.min(100, newStats.power + effects.power));
        if (typeof effects.morality === 'number') newStats.morality = Math.max(-100, Math.min(100, newStats.morality + effects.morality));
        if (typeof effects.corruption === 'number') newStats.corruption = Math.max(0, Math.min(100, newStats.corruption + effects.corruption));
        if (typeof effects.money === 'number') newStats.money += effects.money;
      }

      let newAlignment = prev.alignment;
      if (stateChanges?.alignment) {
        newAlignment = stateChanges.alignment;
      } else {
        if (newStats.morality > 50 && newStats.corruption < 30) newAlignment = 'hero';
        else if (newStats.morality < -50 || newStats.corruption > 70) newAlignment = 'villain';
        else if (newStats.corruption > 40 && newStats.morality < 0) newAlignment = 'rogue';
        else newAlignment = 'neutral';
      }

      let newJob = prev.job;
      if (stateChanges?.job !== undefined) {
        const jobTitle = stateChanges.job.toLowerCase();
        if (jobTitle === 'işsiz' || jobTitle === 'null' || jobTitle === '') {
          newJob = null;
        } else {
          const existingJob = AVAILABLE_JOBS.find(j => j.title.toLowerCase() === jobTitle);
          newJob = existingJob || {
            id: 'custom_' + Date.now(),
            title: stateChanges.job,
            salary: stateChanges.salary || 30000,
            type: 'normal'
          };
        }
      }

      let newVStatus = stateChanges?.compound_v_status || prev.vStatus;

      let newAssets = [...prev.assets];
      if (stateChanges?.owned_assets_add) {
        stateChanges.owned_assets_add.forEach(assetName => {
          const existing = BUYABLE_ASSETS.find(a => a.name === assetName);
          newAssets.push(existing || { 
            id: 'custom_' + Date.now() + Math.random(), 
            name: assetName, 
            type: 'misc', 
            value: 10000, 
            maintenanceCost: 500 
          });
        });
      }
      if (stateChanges?.owned_assets_remove) {
        stateChanges.owned_assets_remove.forEach(assetName => {
          const index = newAssets.findIndex(a => a.name === assetName);
          if (index !== -1) newAssets.splice(index, 1);
        });
      }

      let newFollowers = prev.social.followers + (stateChanges?.followers || 0);

      // Power Mutations
      let newPowers = [...prev.powers];
      if (stateChanges?.powers_add) {
        newPowers.push(...stateChanges.powers_add.map(p => ({ ...p, id: 'p_' + Date.now() + Math.random() })));
      }
      if (stateChanges?.powers_remove) {
        newPowers = newPowers.filter(p => !stateChanges.powers_remove!.includes(p.name));
      }
      if (stateChanges?.power_mutations) {
        stateChanges.power_mutations.forEach(mut => {
          const pIndex = newPowers.findIndex(p => p.name === mut.name);
          if (pIndex !== -1) {
            const p = { ...newPowers[pIndex] };
            if (mut.control_change) p.control_level = Math.max(0, Math.min(100, p.control_level + mut.control_change));
            if (mut.strength_change) p.strength_level = Math.max(0, Math.min(100, p.strength_level + mut.strength_change));
            if (mut.new_side_effect && !p.side_effects.includes(mut.new_side_effect)) p.side_effects = [...p.side_effects, mut.new_side_effect];
            if (mut.new_ability && !p.abilities.includes(mut.new_ability)) p.abilities = [...p.abilities, mut.new_ability];
            newPowers[pIndex] = p;
          }
        });
      }

      const isGameOver = newStats.health <= 0;
      const deathReason = isGameOver ? "Sağlığın tükendi ve hayata veda ettin." : prev.deathReason;

      return { 
        ...prev, 
        stats: newStats, 
        alignment: newAlignment, 
        job: newJob,
        vStatus: newVStatus,
        assets: newAssets,
        powers: newPowers,
        social: { ...prev.social, followers: Math.max(0, newFollowers) },
        isGameOver, 
        deathReason 
      };
    });
  }, []);

  const advanceYear = useCallback(async () => {
    if (state.isGameOver) return;
    
    if (state.currentYearEvents.some(e => !e.resolved)) {
      alert("Lütfen önce bu yılki tüm olayları tamamlayın.");
      return;
    }

    setIsLoading(true);

    let yearlyIncome = state.job ? state.job.salary * 12 : 0;
    let yearlyExpenses = state.assets.reduce((sum, asset) => sum + asset.maintenanceCost * 12, 0);
    
    const newMarket = state.market.map(stock => {
      const volatility = 0.2;
      const change = 1 + (Math.random() * volatility * 2 - volatility);
      const newPrice = Math.max(1, Math.round(stock.price * change));
      return {
        ...stock,
        price: newPrice,
        history: [...stock.history.slice(-9), newPrice]
      };
    });

    const socialChange = Math.floor(state.social.followers * (state.stats.fame / 100) * 0.1);
    
    let newVStatus = state.vStatus;
    let powerDrop = 0;
    let newPowers = [...state.powers];

    // Temporary V wears off
    if (state.vStatus === 'temporary') {
      newVStatus = 'none';
      powerDrop = -30;
      newPowers = []; // Lose all powers
    }

    setState(prev => ({
      ...prev,
      stats: {
        ...prev.stats,
        age: prev.stats.age + 1,
        money: prev.stats.money + yearlyIncome - yearlyExpenses,
        power: Math.max(0, prev.stats.power + powerDrop)
      },
      social: {
        ...prev.social,
        followers: prev.social.followers + socialChange
      },
      market: newMarket,
      vStatus: newVStatus,
      powers: newPowers,
      eventHistory: [...prev.eventHistory, ...prev.currentYearEvents]
    }));

    const stateForAI = { ...state, stats: { ...state.stats, age: state.stats.age + 1 }, vStatus: newVStatus, powers: newPowers };
    const aiResponse = await generateYearlyEvents(stateForAI);

    let sortedEvents = sortEventsByDate(aiResponse.events);

    if (sortedEvents.length === 0) {
      sortedEvents = [{
        id: `fallback_${Date.now()}`,
        type: 'single',
        date: '1 Ocak',
        title: 'Sakin Bir Yıl',
        steps: [
          {
            text: 'Bu yıl pek kayda değer bir şey olmadı. Rutin hayatına devam ettin.',
            choices: [
              {
                text: 'Hayata devam et',
                effects: { health: 5 },
                next_step: false
              }
            ]
          }
        ],
        final_outcome: 'Sıradan bir yıl geride kaldı.',
        resolved: false
      }];
    }

    setState(prev => ({
      ...prev,
      currentYearEvents: sortedEvents
    }));

    setIsLoading(false);
  }, [state]);

  const resolveEvent = useCallback((eventId: string) => {
    setState(prev => ({
      ...prev,
      currentYearEvents: prev.currentYearEvents.map(e => 
        e.id === eventId ? { ...e, resolved: true } : e
      )
    }));
  }, []);

  const takeJob = useCallback((job: Job) => {
    setState(prev => ({ ...prev, job }));
  }, []);

  const quitJob = useCallback(() => {
    setState(prev => ({ ...prev, job: null }));
  }, []);

  const buyAsset = useCallback((asset: Asset) => {
    if (state.stats.money >= asset.value) {
      setState(prev => ({
        ...prev,
        stats: { ...prev.stats, money: prev.stats.money - asset.value },
        assets: [...prev.assets, asset]
      }));
    }
  }, [state.stats.money]);

  const sellAsset = useCallback((assetId: string) => {
    const asset = state.assets.find(a => a.id === assetId);
    if (asset) {
      setState(prev => ({
        ...prev,
        stats: { ...prev.stats, money: prev.stats.money + Math.floor(asset.value * 0.8) },
        assets: prev.assets.filter(a => a.id !== assetId)
      }));
    }
  }, [state.assets]);

  const buyStock = useCallback((symbol: string, amount: number) => {
    const stock = state.market.find(s => s.symbol === symbol);
    if (!stock) return;
    const cost = stock.price * amount;
    
    if (state.stats.money >= cost) {
      setState(prev => {
        const existing = prev.portfolio.find(p => p.symbol === symbol);
        let newPortfolio;
        if (existing) {
          newPortfolio = prev.portfolio.map(p => 
            p.symbol === symbol 
              ? { ...p, shares: p.shares + amount, averagePrice: ((p.shares * p.averagePrice) + cost) / (p.shares + amount) }
              : p
          );
        } else {
          newPortfolio = [...prev.portfolio, { symbol, shares: amount, averagePrice: stock.price }];
        }
        return {
          ...prev,
          stats: { ...prev.stats, money: prev.stats.money - cost },
          portfolio: newPortfolio
        };
      });
    }
  }, [state.market, state.stats.money]);

  const sellStock = useCallback((symbol: string, amount: number) => {
    const stock = state.market.find(s => s.symbol === symbol);
    if (!stock) return;
    
    setState(prev => {
      const existing = prev.portfolio.find(p => p.symbol === symbol);
      if (!existing || existing.shares < amount) return prev;

      const revenue = stock.price * amount;
      const newPortfolio = existing.shares === amount 
        ? prev.portfolio.filter(p => p.symbol !== symbol)
        : prev.portfolio.map(p => p.symbol === symbol ? { ...p, shares: p.shares - amount } : p);

      return {
        ...prev,
        stats: { ...prev.stats, money: prev.stats.money + revenue },
        portfolio: newPortfolio
      };
    });
  }, [state.market]);

  const buyCompoundV = useCallback((type: 'temporary' | 'permanent' | 'cleanse') => {
    const price = COMPOUND_V_PRICES[type];
    if (state.stats.money >= price) {
      setState(prev => {
        let newPower = prev.stats.power;
        let newHealth = prev.stats.health;
        let newCorruption = prev.stats.corruption;
        let newVStatus = prev.vStatus;
        let newPowers = [...prev.powers];

        if (type === 'temporary') {
          newPower = Math.min(100, newPower + 40);
          newHealth -= 10;
          newCorruption += 10;
          newVStatus = 'temporary';
          newPowers = [...newPowers, ...generateRandomPowers()];
        } else if (type === 'permanent') {
          newPower = Math.min(100, newPower + 80);
          newHealth -= 20;
          newCorruption += 30;
          newVStatus = 'permanent';
          newPowers = [...newPowers, ...generateRandomPowers()];
        } else if (type === 'cleanse') {
          newPower = Math.max(0, newPower - 80);
          newCorruption = Math.max(0, newCorruption - 50);
          newVStatus = 'none';
          newPowers = [];
        }

        return {
          ...prev,
          stats: {
            ...prev.stats,
            money: prev.stats.money - price,
            power: newPower,
            health: newHealth,
            corruption: newCorruption
          },
          vStatus: newVStatus,
          powers: newPowers
        };
      });
    }
  }, [state.stats.money]);

  const restartGame = useCallback(() => {
    setState(INITIAL_STATE);
    localStorage.removeItem(SAVE_KEY);
  }, []);

  return {
    state,
    isLoading,
    updateStats,
    advanceYear,
    resolveEvent,
    takeJob,
    quitJob,
    buyAsset,
    sellAsset,
    buyStock,
    sellStock,
    buyCompoundV,
    restartGame
  };
}
