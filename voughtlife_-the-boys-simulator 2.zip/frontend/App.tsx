import React, { useState, useEffect } from 'react';
import { useGame } from './hooks/useGame';
import { StatBar } from './components/StatBar';
import { EventCard } from './components/EventCard';
import { JobPanel, AssetPanel, MarketPanel, CompoundVPanel } from './components/Panels';
import { Activity, DollarSign, Shield, Skull, Zap, AlertTriangle, Briefcase, CheckCircle2 } from 'lucide-react';

type Tab = 'life' | 'job' | 'assets' | 'market' | 'v';

export default function App() {
  const { 
    state, isLoading, updateStats, advanceYear, resolveEvent, 
    takeJob, quitJob, buyAsset, sellAsset, buyStock, sellStock, buyCompoundV, restartGame 
  } = useGame();
  
  const [activeTab, setActiveTab] = useState<Tab>('life');
  const [gameStarted, setGameStarted] = useState(false);

  // Check if there is an existing save game
  const hasSave = state.stats.age > 18 || state.eventHistory.length > 0 || state.currentYearEvents.length > 0;

  // Initial event generation on start if it's a brand new game
  useEffect(() => {
    if (gameStarted && state.currentYearEvents.length === 0 && state.stats.age === 18 && !hasSave) {
      advanceYear(); // Trigger first year generation
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameStarted]);

  if (!gameStarted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-vought-dark p-4">
        <div className="max-w-md w-full bg-slate-800 p-8 rounded-xl border border-slate-700 text-center shadow-2xl">
          <h1 className="text-4xl font-black text-white mb-2 tracking-tighter">VOUGHT<span className="text-vought-red">LIFE</span></h1>
          <p className="text-slate-400 mb-8">The Boys Evreninde Hayatta Kal</p>
          
          <div className="space-y-4">
            <button 
              onClick={() => setGameStarted(true)}
              className="w-full py-4 bg-vought-red hover:bg-red-700 text-white font-bold rounded-lg text-lg transition-all transform hover:scale-105"
            >
              {hasSave ? 'Oyuna Devam Et' : 'Hayata Başla'}
            </button>
            
            {hasSave && (
              <button 
                onClick={() => {
                  if (window.confirm("Mevcut kayıt silinecek. Emin misin?")) {
                    restartGame();
                    setGameStarted(true);
                  }
                }}
                className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-lg transition-colors"
              >
                Yeni Oyun
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (state.isGameOver) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-vought-dark p-4">
        <div className="max-w-md w-full bg-slate-800 p-8 rounded-xl border border-red-900 text-center shadow-2xl">
          <Skull size={64} className="mx-auto text-red-500 mb-4" />
          <h1 className="text-3xl font-black text-white mb-2">ÖLDÜN</h1>
          <p className="text-slate-300 mb-6">{state.deathReason}</p>
          <div className="bg-slate-900 p-4 rounded mb-6 text-left text-sm text-slate-400 space-y-2">
            <p>Yaş: {state.stats.age}</p>
            <p>Servet: ${state.stats.money.toLocaleString()}</p>
            <p>Hizalama: <span className="uppercase font-bold text-white">{state.alignment}</span></p>
          </div>
          <button 
            onClick={() => {
              restartGame();
              setGameStarted(false);
            }}
            className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-lg transition-colors"
          >
            Yeniden Doğ
          </button>
        </div>
      </div>
    );
  }

  // Find the first unresolved event to show in the modal
  const activeEvent = state.currentYearEvents.find(e => !e.resolved);
  const hasUnresolvedEvents = !!activeEvent;

  return (
    <div className="min-h-screen bg-vought-dark flex flex-col md:flex-row relative">
      
      {/* EVENT MODAL OVERLAY */}
      {activeEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg animate-slide-up">
            <EventCard 
              key={activeEvent.id} // Ensure re-render on new event
              event={activeEvent} 
              onResolve={resolveEvent} 
              onApplyEffects={updateStats} 
            />
          </div>
        </div>
      )}

      {/* LEFT SIDEBAR: STATS */}
      <div className="w-full md:w-80 bg-slate-900 border-r border-slate-800 p-6 flex flex-col h-auto md:h-screen sticky top-0 overflow-y-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-black text-white tracking-tighter mb-1">VOUGHT<span className="text-vought-red">LIFE</span></h1>
          <div className="flex justify-between text-slate-400 text-sm">
            <span>Yaş: {state.stats.age}</span>
            <span className="uppercase font-bold text-amber-500">{state.alignment}</span>
          </div>
        </div>

        <div className="space-y-4 mb-8">
          <StatBar label="Sağlık" value={state.stats.health} colorClass="bg-emerald-500" />
          <StatBar label="Şöhret" value={state.stats.fame} colorClass="bg-blue-500" />
          <StatBar label="Güç" value={state.stats.power} colorClass="bg-purple-500" />
          <StatBar label="Ahlak" value={state.stats.morality} min={-100} max={100} colorClass="bg-amber-500" />
          <StatBar label="Yozlaşma" value={state.stats.corruption} colorClass="bg-vought-red" />
        </div>

        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700 mb-6">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xl mb-2">
            <DollarSign size={20} />
            {state.stats.money.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 space-y-1">
            <p>Maaş: ${state.job ? state.job.salary.toLocaleString() : 0}/yıl</p>
            <p>Takipçi: {state.social.followers.toLocaleString()}</p>
            <p>V Durumu: <span className="uppercase text-purple-400">{state.vStatus}</span></p>
          </div>
        </div>

        <div className="mt-auto pt-4">
          <button
            onClick={advanceYear}
            disabled={isLoading || hasUnresolvedEvents}
            className="w-full py-4 bg-vought-red hover:bg-red-700 disabled:bg-slate-700 disabled:text-slate-500 text-white font-black text-lg rounded-lg transition-all shadow-lg flex justify-center items-center gap-2"
          >
            {isLoading ? (
              <span className="animate-pulse">Yükleniyor...</span>
            ) : hasUnresolvedEvents ? (
              <>Olayları Çöz <AlertTriangle size={18}/></>
            ) : (
              'SONRAKİ YIL'
            )}
          </button>
        </div>
      </div>

      {/* RIGHT MAIN CONTENT */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* TABS */}
        <div className="bg-slate-900 border-b border-slate-800 p-4 flex gap-2 overflow-x-auto">
          <TabButton active={activeTab === 'life'} onClick={() => setActiveTab('life')} icon={<Activity size={16}/>} label="Hayat" />
          <TabButton active={activeTab === 'job'} onClick={() => setActiveTab('job')} icon={<Briefcase size={16}/>} label="Kariyer" />
          <TabButton active={activeTab === 'assets'} onClick={() => setActiveTab('assets')} icon={<Shield size={16}/>} label="Varlıklar" />
          <TabButton active={activeTab === 'market'} onClick={() => setActiveTab('market')} icon={<DollarSign size={16}/>} label="Borsa" />
          <TabButton active={activeTab === 'v'} onClick={() => setActiveTab('v')} icon={<Zap size={16}/>} label="Karaborsa" />
        </div>

        {/* CONTENT AREA */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-3xl mx-auto">
            
            {activeTab === 'life' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-white mb-4 border-b border-slate-700 pb-2">Yıl {state.stats.age} Özeti</h2>
                
                {state.currentYearEvents.length === 0 && !isLoading && (
                  <p className="text-slate-400 italic">Bu yıl henüz bir şey olmadı. Sonraki yıla geç.</p>
                )}

                {/* Show resolved events for the current year as a log */}
                <div className="space-y-3">
                  {state.currentYearEvents.filter(e => e.resolved).map(event => (
                    <div key={event.id} className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 flex items-center gap-3">
                      <CheckCircle2 size={20} className="text-emerald-500 flex-shrink-0" />
                      <div>
                        <p className="text-slate-200 font-semibold">{event.date} - {event.title}</p>
                        <p className="text-slate-400 text-sm italic">"{event.final_outcome}"</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* History Log */}
                {state.eventHistory.length > 0 && (
                  <div className="mt-12">
                    <h3 className="text-lg font-bold text-slate-500 mb-4">Geçmiş Yıllar</h3>
                    <div className="space-y-2 opacity-60">
                      {state.eventHistory.slice(-10).reverse().map(event => (
                        <div key={event.id} className="text-sm text-slate-400 border-l-2 border-slate-700 pl-3 py-1">
                          <span className="font-mono mr-2 text-slate-500">{event.date}</span>
                          {event.title}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'job' && <JobPanel state={state} onTakeJob={takeJob} onQuitJob={quitJob} />}
            {activeTab === 'assets' && <AssetPanel state={state} onBuy={buyAsset} onSell={sellAsset} />}
            {activeTab === 'market' && <MarketPanel state={state} onBuy={buyStock} onSell={sellStock} />}
            {activeTab === 'v' && <CompoundVPanel state={state} onBuyV={buyCompoundV} />}

          </div>
        </div>
      </div>
    </div>
  );
}

// Helper component for tabs
const TabButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
      active ? 'bg-slate-700 text-white' : 'bg-transparent text-slate-400 hover:bg-slate-800 hover:text-slate-200'
    }`}
  >
    {icon}
    {label}
  </button>
);
