import { GoogleGenAI, Type } from '@google/genai';
import { GameState, AIYearResponse } from '../types';

// Polyfill process.env to prevent ReferenceError in pure browser environments
if (typeof process === 'undefined') {
  (window as any).process = { env: { API_KEY: 'dummy_key' } };
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY, vertexai: true });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    year: { type: Type.INTEGER },
    events: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          type: { type: Type.STRING, description: "Must be 'single', 'multi', or 'micro'" },
          date: { type: Type.STRING, description: "e.g., '12 Mart'" },
          title: { type: Type.STRING },
          steps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                choices: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      text: { type: Type.STRING },
                      effects: {
                        type: Type.OBJECT,
                        properties: {
                          health: { type: Type.INTEGER },
                          fame: { type: Type.INTEGER },
                          power: { type: Type.INTEGER },
                          morality: { type: Type.INTEGER },
                          money: { type: Type.INTEGER },
                          corruption: { type: Type.INTEGER }
                        }
                      },
                      state_changes: {
                        type: Type.OBJECT,
                        properties: {
                          job: { type: Type.STRING },
                          salary: { type: Type.INTEGER },
                          compound_v_status: { type: Type.STRING },
                          alignment: { type: Type.STRING },
                          owned_assets_add: { type: Type.ARRAY, items: { type: Type.STRING } },
                          owned_assets_remove: { type: Type.ARRAY, items: { type: Type.STRING } },
                          followers: { type: Type.INTEGER },
                          powers_add: {
                            type: Type.ARRAY,
                            items: {
                              type: Type.OBJECT,
                              properties: {
                                name: { type: Type.STRING },
                                description: { type: Type.STRING },
                                type: { type: Type.STRING },
                                strength_level: { type: Type.INTEGER },
                                control_level: { type: Type.INTEGER },
                                visibility: { type: Type.STRING },
                                side_effects: { type: Type.ARRAY, items: { type: Type.STRING } },
                                abilities: { type: Type.ARRAY, items: { type: Type.STRING } }
                              }
                            }
                          },
                          powers_remove: { type: Type.ARRAY, items: { type: Type.STRING } },
                          power_mutations: {
                            type: Type.ARRAY,
                            items: {
                              type: Type.OBJECT,
                              properties: {
                                name: { type: Type.STRING },
                                control_change: { type: Type.INTEGER },
                                strength_change: { type: Type.INTEGER },
                                new_side_effect: { type: Type.STRING },
                                new_ability: { type: Type.STRING }
                              }
                            }
                          }
                        }
                      },
                      next_step: { type: Type.BOOLEAN }
                    }
                  }
                }
              }
            }
          },
          final_outcome: { type: Type.STRING }
        }
      }
    }
  },
  required: ["year", "events"]
};

export async function generateYearlyEvents(gameState: GameState): Promise<AIYearResponse> {
  const powersText = gameState.powers.length > 0 
    ? gameState.powers.map(p => `[${p.name}] (Güç: ${p.strength_level}, Kontrol: ${p.control_level}, Görünürlük: ${p.visibility}) - Yetenekler: ${p.abilities.join(', ')} - Yan Etkiler: ${p.side_effects.join(', ')}`).join(' | ')
    : 'Yok';

  const prompt = `
Sen The Boys evreninde geçen bir yaşam simülasyonu oyununun (BitLife tarzı) "Yapay Zeka Hikaye Yönetmeni"sin.
Oyuncunun mevcut durumuna göre 1 yıllık olaylar silsilesi oluşturmalısın.
TÜM YANITLARIN KESİNLİKLE TÜRKÇE OLMALIDIR.

Oyuncu Durumu:
- Yaş: ${gameState.stats.age}
- Sağlık: ${gameState.stats.health}/100
- Şöhret: ${gameState.stats.fame}/100
- Güç: ${gameState.stats.power}/100
- Ahlak: ${gameState.stats.morality} (-100 Kötü, 100 İyi)
- Yozlaşma: ${gameState.stats.corruption}/100
- Para: $${gameState.stats.money}
- Meslek: ${gameState.job ? gameState.job.title : 'İşsiz'}
- Compound V Durumu: ${gameState.vStatus}
- Hizalama: ${gameState.alignment}
- Varlıklar: ${gameState.assets.map(a => a.name).join(', ') || 'Yok'}
- Takipçi: ${gameState.social.followers}
- SÜPER GÜÇLER: ${powersText}

Kurallar:
1. 3 ila 6 arası olay üret (single, multi, veya micro tiplerinde karışık).
2. Olaylar The Boys evrenine uygun olmalı (Vought, Supe'lar, yozlaşma, medya skandalları vb.).
3. ÖNEMLİ: Oyuncunun SÜPER GÜÇLERİ varsa, olaylar ve seçenekler KESİNLİKLE bu güçlere göre şekillenmelidir!
   - Güçlerini kullanabileceği özel seçenekler sun (Örn: "Lazer gözlerinle kapıyı erit").
   - Kontrol seviyesi (control_level) düşükse, güçlerin kontrolden çıktığı felaket olayları yarat (Örn: "Hapşırırken yanlışlıkla birini patlattın").
   - Görünür (public) mutasyonları varsa, halkın veya medyanın tepkisini içeren olaylar yaz (Örn: "Devasa kolun yüzünden restorandan kovuldun").
   - Güçlerin yan etkileri (side_effects) başını belaya soksun.
4. Olayların kalıcı sonuçları olmalıdır! Sadece statları değiştirmekle kalma, 'state_changes' kullanarak kalıcı değişiklikler yap.
   - Güç gelişimi: "power_mutations": [{ "name": "Lazer Gözler", "control_change": 10, "new_ability": "Hassas Kesim" }]
   - Yeni güç kazanımı (Eğer Vought deneyi vb. olursa): "powers_add": [...]
   - İş, varlık, hizalama değişiklikleri.
5. SADECE JSON formatında yanıt ver.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        temperature: 0.7,
      }
    });

    let text = response.text;
    if (!text) {
      throw new Error("Empty response from AI");
    }

    text = text.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim();
    const data = JSON.parse(text) as AIYearResponse;
    
    if (!data || !Array.isArray(data.events)) {
      throw new Error("Invalid AI response format");
    }

    data.events = data.events.map(e => ({
      ...e,
      id: `evt_${gameState.stats.age}_${Math.random().toString(36).substr(2, 9)}`,
      resolved: false
    }));

    return data;
  } catch (error) {
    console.error("Error generating events:", error);
    return {
      year: gameState.stats.age,
      events: [
        {
          id: `fallback_${Date.now()}`,
          type: 'single',
          date: '1 Ocak',
          title: 'Sakin Bir Yıl',
          steps: [
            {
              text: 'Bu yıl pek kayda değer bir şey olmadı. Rutin hayatına devam ettin.',
              choices: [
                {
                  text: 'Hayata devam et',
                  effects: { health: 5 },
                  next_step: false
                }
              ]
            }
          ],
          final_outcome: 'Sıradan bir yıl geride kaldı.',
          resolved: false
        }
      ]
    };
  }
}
