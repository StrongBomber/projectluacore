import React from 'react';

interface StatBarProps {
  label: string;
  value: number;
  colorClass: string;
  min?: number;
  max?: number;
}

export const StatBar: React.FC<StatBarProps> = ({ label, value, colorClass, min = 0, max = 100 }) => {
  // Normalize value for percentage display if min is negative (like morality)
  const range = max - min;
  const percentage = Math.max(0, Math.min(100, ((value - min) / range) * 100));

  return (
    <div className="mb-2">
      <div className="flex justify-between text-xs mb-1 text-slate-300 font-medium uppercase tracking-wider">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="w-full bg-slate-800 rounded-full h-2.5 border border-slate-700">
        <div 
          className={`h-2.5 rounded-full ${colorClass} transition-all duration-500 ease-out`} 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};
