import React, { useState } from 'react';
import { GameEvent, ChoiceEffects, StateChanges } from '../types';
import { AlertCircle } from 'lucide-react';

interface EventCardProps {
  event: GameEvent;
  onResolve: (eventId: string) => void;
  onApplyEffects: (effects?: ChoiceEffects, stateChanges?: StateChanges) => void;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onResolve, onApplyEffects }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [showOutcome, setShowOutcome] = useState(false);
  const [appliedConsequences, setAppliedConsequences] = useState<{effects?: ChoiceEffects, stateChanges?: StateChanges} | null>(null);

  const currentStep = event.steps?.[currentStepIndex];

  const handleChoice = (choice: any) => {
    if (choice?.effects || choice?.state_changes) {
      onApplyEffects(choice.effects, choice.state_changes);
      setAppliedConsequences({ effects: choice.effects, stateChanges: choice.state_changes });
    } else {
      setAppliedConsequences(null);
    }

    if (choice?.next_step && currentStepIndex < (event.steps?.length || 0) - 1) {
      setCurrentStepIndex(prev => prev + 1);
      setAppliedConsequences(null); // Clear effects display for next step
    } else {
      setShowOutcome(true);
    }
  };

  const finishEvent = () => {
    onResolve(event.id);
  };

  const renderConsequences = (data: {effects?: ChoiceEffects, stateChanges?: StateChanges}) => {
    const items = [];
    const { effects, stateChanges } = data;

    // Render Stat Effects
    if (effects) {
      if (typeof effects.health === 'number') items.push(<span key="h" className={effects.health > 0 ? 'text-emerald-400' : 'text-red-400'}>Sağlık {effects.health > 0 ? '+' : ''}{effects.health}</span>);
      if (typeof effects.money === 'number') items.push(<span key="m" className={effects.money > 0 ? 'text-emerald-400' : 'text-red-400'}>Para {effects.money > 0 ? '+' : ''}${effects.money}</span>);
      if (typeof effects.fame === 'number') items.push(<span key="f" className={effects.fame > 0 ? 'text-blue-400' : 'text-red-400'}>Şöhret {effects.fame > 0 ? '+' : ''}{effects.fame}</span>);
      if (typeof effects.power === 'number') items.push(<span key="p" className={effects.power > 0 ? 'text-purple-400' : 'text-red-400'}>Güç {effects.power > 0 ? '+' : ''}{effects.power}</span>);
      if (typeof effects.morality === 'number') items.push(<span key="mo" className={effects.morality > 0 ? 'text-emerald-400' : 'text-red-400'}>Ahlak {effects.morality > 0 ? '+' : ''}{effects.morality}</span>);
      if (typeof effects.corruption === 'number') items.push(<span key="c" className={effects.corruption > 0 ? 'text-red-400' : 'text-emerald-400'}>Yozlaşma {effects.corruption > 0 ? '+' : ''}{effects.corruption}</span>);
    }

    // Render State Changes
    if (stateChanges) {
      if (stateChanges.job) items.push(<span key="sc_job" className="text-blue-300 font-bold">Yeni İş: {stateChanges.job}</span>);
      if (stateChanges.compound_v_status) items.push(<span key="sc_v" className="text-purple-400 font-bold">V Durumu: {stateChanges.compound_v_status.toUpperCase()}</span>);
      if (stateChanges.alignment) items.push(<span key="sc_align" className="text-amber-400 font-bold">Hizalama: {stateChanges.alignment.toUpperCase()}</span>);
      if (stateChanges.owned_assets_add) {
        stateChanges.owned_assets_add.forEach((a, i) => items.push(<span key={`sc_add_${i}`} className="text-emerald-300 font-bold">Kazanıldı: {a}</span>));
      }
      if (stateChanges.owned_assets_remove) {
        stateChanges.owned_assets_remove.forEach((a, i) => items.push(<span key={`sc_rem_${i}`} className="text-red-300 font-bold">Kaybedildi: {a}</span>));
      }
      if (typeof stateChanges.followers === 'number') {
        items.push(<span key="sc_foll" className={stateChanges.followers > 0 ? 'text-emerald-400' : 'text-red-400'}>Takipçi {stateChanges.followers > 0 ? '+' : ''}{stateChanges.followers}</span>);
      }
      if (stateChanges.powers_add) {
        stateChanges.powers_add.forEach((p, i) => items.push(<span key={`sc_padd_${i}`} className="text-purple-400 font-bold">Yeni Güç: {p.name}</span>));
      }
      if (stateChanges.powers_remove) {
        stateChanges.powers_remove.forEach((p, i) => items.push(<span key={`sc_prem_${i}`} className="text-red-400 font-bold">Güç Kaybedildi: {p}</span>));
      }
      if (stateChanges.power_mutations) {
        stateChanges.power_mutations.forEach((m, i) => {
          if (m.control_change) items.push(<span key={`sc_pmc_${i}`} className="text-blue-300">Güç Kontrolü ({m.name}): {m.control_change > 0 ? '+' : ''}{m.control_change}</span>);
          if (m.strength_change) items.push(<span key={`sc_pms_${i}`} className="text-purple-300">Güç Seviyesi ({m.name}): {m.strength_change > 0 ? '+' : ''}{m.strength_change}</span>);
          if (m.new_side_effect) items.push(<span key={`sc_pmse_${i}`} className="text-red-400">Yeni Yan Etki ({m.name}): {m.new_side_effect}</span>);
          if (m.new_ability) items.push(<span key={`sc_pma_${i}`} className="text-emerald-400">Yeni Yetenek ({m.name}): {m.new_ability}</span>);
        });
      }
    }
    
    if (items.length === 0) return null;
    return <div className="flex flex-wrap gap-3 text-sm mt-3 p-3 bg-slate-900 rounded border border-slate-700">{items}</div>;
  };

  return (
    <div className="bg-slate-800 border border-slate-600 rounded-xl p-6 shadow-2xl relative overflow-hidden w-full">
      {/* Type indicator strip */}
      <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${
        event.type === 'multi' ? 'bg-purple-500' : 
        event.type === 'micro' ? 'bg-blue-500' : 'bg-amber-500'
      }`}></div>

      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <AlertCircle size={22} className="text-amber-400" />
          {event.title || "Bilinmeyen Olay"}
        </h3>
        <span className="text-sm font-mono text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-slate-700">{event.date || "Bilinmeyen Tarih"}</span>
      </div>

      {!showOutcome ? (
        <div className="animate-fade-in">
          <p className="text-slate-200 mb-6 leading-relaxed text-lg">{currentStep?.text || "Ne yapacaksın?"}</p>
          
          <div className="space-y-3">
            {currentStep?.choices && currentStep.choices.length > 0 ? (
              currentStep.choices.map((choice, idx) => (
                <button
                  key={idx}
                  onClick={() => handleChoice(choice)}
                  className="w-full text-left px-5 py-4 bg-slate-700 hover:bg-slate-600 border border-slate-600 hover:border-slate-400 rounded-lg transition-colors text-base font-medium shadow-sm"
                >
                  {choice.text || "Seçim"}
                </button>
              ))
            ) : (
              <button
                onClick={() => setShowOutcome(true)}
                className="w-full text-left px-5 py-4 bg-slate-700 hover:bg-slate-600 border border-slate-600 hover:border-slate-400 rounded-lg transition-colors text-base font-medium shadow-sm"
              >
                Devam Et
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="animate-fade-in">
          <div className="bg-slate-900/80 p-5 rounded-lg border border-slate-700 mb-6">
            <p className="text-slate-200 italic text-lg mb-2">"{event.final_outcome || "Olay sonuçlandı."}"</p>
            {appliedConsequences && renderConsequences(appliedConsequences)}
          </div>
          <button
            onClick={finishEvent}
            className="w-full py-3 bg-vought-red hover:bg-red-700 text-white font-bold rounded-lg transition-colors text-lg shadow-md"
          >
            Devam Et
          </button>
        </div>
      )}
    </div>
  );
};
