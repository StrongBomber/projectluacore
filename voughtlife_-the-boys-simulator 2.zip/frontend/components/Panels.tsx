import React, { useState } from 'react';
import { GameState, Job, Asset } from '../types';
import { AVAILABLE_JOBS, BUYABLE_ASSETS, COMPOUND_V_PRICES } from '../constants';
import { Briefcase, Home, TrendingUp, Zap, ShieldAlert, Brain, Eye, Activity } from 'lucide-react';

// --- JOB PANEL ---
export const JobPanel: React.FC<{ state: GameState, onTakeJob: (j: Job) => void, onQuitJob: () => void }> = ({ state, onTakeJob, onQuitJob }) => {
  return (
    <div className="space-y-6">
      <div className="bg-slate-800 p-5 rounded-lg border border-slate-700">
        <h3 className="text-xl font-bold mb-2 flex items-center gap-2"><Briefcase className="text-blue-400"/> Mevcut İşin</h3>
        {state.job ? (
          <div>
            <p className="text-lg text-white">{state.job.title}</p>
            <p className="text-emerald-400 font-mono">${state.job.salary.toLocaleString()}/yıl</p>
            <button onClick={onQuitJob} className="mt-4 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded text-sm">İşi Bırak</button>
          </div>
        ) : (
          <p className="text-slate-400">Şu an işsizsin.</p>
        )}
      </div>

      <div className="bg-slate-800 p-5 rounded-lg border border-slate-700">
        <h3 className="text-xl font-bold mb-4">İş İlanları</h3>
        <div className="space-y-3">
          {AVAILABLE_JOBS.map(job => {
            const canApply = (job.requiredFame || 0) <= state.stats.fame && (job.requiredPower || 0) <= state.stats.power;
            return (
              <div key={job.id} className="flex justify-between items-center p-3 bg-slate-900 rounded border border-slate-700">
                <div>
                  <p className="font-semibold text-slate-200">{job.title}</p>
                  <p className="text-sm text-emerald-400">${job.salary.toLocaleString()}/yıl</p>
                  {!canApply && (
                    <p className="text-xs text-red-400 mt-1">
                      Gereksinimler: {job.requiredFame ? `Şöhret ${job.requiredFame} ` : ''} {job.requiredPower ? `Güç ${job.requiredPower}` : ''}
                    </p>
                  )}
                </div>
                <button 
                  disabled={!canApply || state.job?.id === job.id}
                  onClick={() => onTakeJob(job)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded text-sm transition-colors"
                >
                  {state.job?.id === job.id ? 'Mevcut' : 'Başvur'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// --- ASSET PANEL ---
export const AssetPanel: React.FC<{ state: GameState, onBuy: (a: Asset) => void, onSell: (id: string) => void }> = ({ state, onBuy, onSell }) => {
  return (
    <div className="space-y-6">
      <div className="bg-slate-800 p-5 rounded-lg border border-slate-700">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2"><Home className="text-amber-400"/> Varlıkların</h3>
        {state.assets.length === 0 ? (
          <p className="text-slate-400">Hiçbir varlığın yok.</p>
        ) : (
          <div className="space-y-3">
            {state.assets.map((asset, idx) => (
              <div key={idx} className="flex justify-between items-center p-3 bg-slate-900 rounded border border-slate-700">
                <div>
                  <p className="font-semibold text-slate-200">{asset.name}</p>
                  <p className="text-xs text-slate-400">Değer: ${asset.value.toLocaleString()} | Gider: ${asset.maintenanceCost}/yıl</p>
                </div>
                <button onClick={() => onSell(asset.id)} className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm">Sat</button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-slate-800 p-5 rounded-lg border border-slate-700">
        <h3 className="text-xl font-bold mb-4">Emlak & Galeri</h3>
        <div className="space-y-3">
          {BUYABLE_ASSETS.map(asset => (
            <div key={asset.id} className="flex justify-between items-center p-3 bg-slate-900 rounded border border-slate-700">
              <div>
                <p className="font-semibold text-slate-200">{asset.name}</p>
                <p className="text-sm text-emerald-400">${asset.value.toLocaleString()}</p>
              </div>
              <button 
                disabled={state.stats.money < asset.value}
                onClick={() => onBuy(asset)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded text-sm transition-colors"
              >
                Satın Al
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// --- MARKET PANEL ---
export const MarketPanel: React.FC<{ state: GameState, onBuy: (s: string, a: number) => void, onSell: (s: string, a: number) => void }> = ({ state, onBuy, onSell }) => {
  const [amount, setAmount] = useState(10);

  return (
    <div className="space-y-6">
      <div className="bg-slate-800 p-5 rounded-lg border border-slate-700">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2"><TrendingUp className="text-emerald-400"/> Borsa</h3>
        
        <div className="mb-4 flex items-center gap-2">
          <label className="text-sm text-slate-400">İşlem Adedi:</label>
          <input 
            type="number" 
            value={amount} 
            onChange={(e) => setAmount(Math.max(1, parseInt(e.target.value) || 1))}
            className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white w-24"
          />
        </div>

        <div className="space-y-4">
          {state.market.map(stock => {
            const portfolioItem = state.portfolio.find(p => p.symbol === stock.symbol);
            const history = stock.history;
            const trend = history.length > 1 ? (history[history.length-1] >= history[history.length-2] ? 'text-emerald-400' : 'text-red-400') : 'text-slate-400';

            return (
              <div key={stock.symbol} className="p-4 bg-slate-900 rounded border border-slate-700">
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <p className="font-bold text-lg text-white">{stock.symbol}</p>
                    <p className="text-xs text-slate-400">{stock.name}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-mono text-lg ${trend}`}>${stock.price}</p>
                    {portfolioItem && <p className="text-xs text-blue-400">Sahip olunan: {portfolioItem.shares}</p>}
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button 
                    disabled={state.stats.money < stock.price * amount}
                    onClick={() => onBuy(stock.symbol, amount)}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-700 text-white rounded text-sm"
                  >
                    Al
                  </button>
                  <button 
                    disabled={!portfolioItem || portfolioItem.shares < amount}
                    onClick={() => onSell(stock.symbol, amount)}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-700 disabled:bg-slate-700 text-white rounded text-sm"
                  >
                    Sat
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// --- COMPOUND V PANEL ---
export const CompoundVPanel: React.FC<{ state: GameState, onBuyV: (type: 'temporary' | 'permanent' | 'cleanse') => void }> = ({ state, onBuyV }) => {
  return (
    <div className="space-y-6">
      
      {/* CURRENT POWERS DISPLAY */}
      {state.powers.length > 0 && (
        <div className="bg-slate-800 p-5 rounded-lg border border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.15)]">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-purple-400"><Activity /> Mevcut Güçlerin</h3>
          <div className="space-y-4">
            {state.powers.map(power => (
              <div key={power.id} className="bg-slate-900 p-4 rounded border border-slate-700">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-lg text-white flex items-center gap-2">
                    {power.type === 'mental' ? <Brain size={18} className="text-blue-400"/> : 
                     power.type === 'elemental' ? <Zap size={18} className="text-amber-400"/> :
                     power.type === 'mutation' ? <ShieldAlert size={18} className="text-red-400"/> :
                     <Eye size={18} className="text-emerald-400"/>}
                    {power.name}
                  </h4>
                  <span className={`text-xs px-2 py-1 rounded ${power.visibility === 'public' ? 'bg-red-900/50 text-red-400' : 'bg-slate-800 text-slate-400'}`}>
                    {power.visibility === 'public' ? 'Görünür Mutasyon' : 'Gizli Güç'}
                  </span>
                </div>
                <p className="text-sm text-slate-300 mb-4">{power.description}</p>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="flex justify-between text-xs mb-1 text-slate-400"><span>Güç Seviyesi</span><span>{power.strength_level}%</span></div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5"><div className="bg-purple-500 h-1.5 rounded-full" style={{width: `${power.strength_level}%`}}></div></div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs mb-1 text-slate-400"><span>Kontrol</span><span>{power.control_level}%</span></div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5"><div className="bg-blue-500 h-1.5 rounded-full" style={{width: `${power.control_level}%`}}></div></div>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-emerald-400 font-semibold">Yetenekler: </span>
                    <span className="text-slate-300">{power.abilities.join(', ')}</span>
                  </div>
                  <div>
                    <span className="text-red-400 font-semibold">Yan Etkiler: </span>
                    <span className="text-slate-300">{power.side_effects.join(', ')}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-slate-800 p-5 rounded-lg border border-vought-red shadow-[0_0_15px_rgba(220,38,38,0.2)]">
        <h3 className="text-xl font-bold mb-2 flex items-center gap-2 text-vought-red"><Zap /> Karaborsa: Compound V</h3>
        <p className="text-sm text-slate-400 mb-6">Vought'un en karanlık sırrı. Güç bedel gerektirir. Rastgele ve tehlikeli mutasyonlara hazır ol.</p>

        <div className="space-y-4">
          <div className="p-4 bg-slate-900 rounded border border-slate-700">
            <h4 className="font-bold text-blue-400">Geçici V (V24)</h4>
            <p className="text-xs text-slate-400 mb-2">24 saatlik rastgele güç. Yan etkileri ölümcül olabilir.</p>
            <div className="flex justify-between items-center">
              <span className="text-emerald-400 font-mono">${COMPOUND_V_PRICES.temporary.toLocaleString()}</span>
              <button 
                disabled={state.stats.money < COMPOUND_V_PRICES.temporary || state.vStatus !== 'none'}
                onClick={() => onBuyV('temporary')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 text-white rounded text-sm"
              >
                Enjekte Et
              </button>
            </div>
          </div>

          <div className="p-4 bg-slate-900 rounded border border-vought-red">
            <h4 className="font-bold text-vought-red">Kalıcı Compound V</h4>
            <p className="text-xs text-slate-400 mb-2">Kalıcı rastgele mutasyon. Geri dönüşü yok. Yüksek yozlaşma.</p>
            <div className="flex justify-between items-center">
              <span className="text-emerald-400 font-mono">${COMPOUND_V_PRICES.permanent.toLocaleString()}</span>
              <button 
                disabled={state.stats.money < COMPOUND_V_PRICES.permanent || state.vStatus === 'permanent'}
                onClick={() => onBuyV('permanent')}
                className="px-4 py-2 bg-vought-red hover:bg-red-700 disabled:bg-slate-700 text-white rounded text-sm"
              >
                Enjekte Et
              </button>
            </div>
          </div>

          <div className="p-4 bg-slate-900 rounded border border-emerald-500">
            <h4 className="font-bold text-emerald-500">V-Cleanse Serumu</h4>
            <p className="text-xs text-slate-400 mb-2">V'yi kandan temizler. Tüm güçleri siler, yozlaşmayı azaltır.</p>
            <div className="flex justify-between items-center">
              <span className="text-emerald-400 font-mono">${COMPOUND_V_PRICES.cleanse.toLocaleString()}</span>
              <button 
                disabled={state.stats.money < COMPOUND_V_PRICES.cleanse || state.vStatus === 'none'}
                onClick={() => onBuyV('cleanse')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-700 text-white rounded text-sm"
              >
                Arın
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
