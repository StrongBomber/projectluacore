export interface PlayerStats {
  age: number;
  health: number;
  fame: number;
  power: number;
  morality: number;
  corruption: number;
  money: number;
}

export interface Job {
  id: string;
  title: string;
  salary: number;
  type: 'normal' | 'vought' | 'supe' | 'criminal';
  requiredFame?: number;
  requiredPower?: number;
}

export interface SocialStats {
  followers: number;
  engagement: number;
  reputation: number;
}

export interface Asset {
  id: string;
  name: string;
  type: 'house' | 'vehicle' | 'misc';
  value: number;
  maintenanceCost: number;
}

export interface Stock {
  symbol: string;
  name: string;
  price: number;
  history: number[];
}

export interface PortfolioItem {
  symbol: string;
  shares: number;
  averagePrice: number;
}

export type CompoundVStatus = 'none' | 'temporary' | 'permanent';
export type PowerType = 'physical' | 'mental' | 'elemental' | 'mutation' | 'strange';
export type PowerVisibility = 'public' | 'hidden';

export interface Power {
  id: string;
  name: string;
  description: string;
  type: PowerType;
  strength_level: number;
  control_level: number;
  visibility: PowerVisibility;
  side_effects: string[];
  abilities: string[];
}

export interface GameState {
  stats: PlayerStats;
  job: Job | null;
  social: SocialStats;
  assets: Asset[];
  portfolio: PortfolioItem[];
  market: Stock[];
  vStatus: CompoundVStatus;
  powers: Power[];
  alignment: 'hero' | 'villain' | 'neutral' | 'rogue';
  eventHistory: GameEvent[];
  currentYearEvents: GameEvent[];
  isGameOver: boolean;
  deathReason?: string;
}

export interface ChoiceEffects {
  health?: number;
  fame?: number;
  power?: number;
  morality?: number;
  money?: number;
  corruption?: number;
}

export interface PowerMutation {
  name: string;
  control_change?: number;
  strength_change?: number;
  new_side_effect?: string;
  new_ability?: string;
}

export interface StateChanges {
  job?: string;
  salary?: number;
  compound_v_status?: CompoundVStatus;
  alignment?: 'hero' | 'villain' | 'neutral' | 'rogue';
  owned_assets_add?: string[];
  owned_assets_remove?: string[];
  followers?: number;
  powers_add?: Omit<Power, 'id'>[];
  powers_remove?: string[];
  power_mutations?: PowerMutation[];
}

export interface EventChoice {
  text: string;
  effects: ChoiceEffects;
  state_changes?: StateChanges;
  next_step: boolean;
}

export interface EventStep {
  text: string;
  choices: EventChoice[];
}

export interface GameEvent {
  id: string;
  type: 'single' | 'multi' | 'micro';
  date: string;
  title: string;
  steps: EventStep[];
  final_outcome: string;
  resolved?: boolean; // Client-side tracking
}

export interface AIYearResponse {
  year: number;
  events: GameEvent[];
}
