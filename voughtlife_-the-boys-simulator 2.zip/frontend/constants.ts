import { GameState, Job, Stock, Asset, Power } from './types';

export const INITIAL_STATE: GameState = {
  stats: {
    age: 18,
    health: 100,
    fame: 10,
    power: 5,
    morality: 50,
    corruption: 0,
    money: 5000,
  },
  job: null,
  social: {
    followers: 150,
    engagement: 5,
    reputation: 50,
  },
  assets: [],
  portfolio: [],
  market: [
    { symbol: 'VOUGHT', name: 'Vought International', price: 150, history: [150] },
    { symbol: 'GLO', name: 'Global Wellness', price: 45, history: [45] },
    { symbol: 'DEF', name: 'National Defense Corp', price: 80, history: [80] },
    { symbol: 'VNN', name: 'Vought News Network', price: 60, history: [60] },
  ],
  vStatus: 'none',
  powers: [],
  alignment: 'neutral',
  eventHistory: [],
  currentYearEvents: [],
  isGameOver: false,
};

export const AVAILABLE_JOBS: Job[] = [
  { id: 'j1', title: 'Kasiyer', salary: 15000, type: 'normal' },
  { id: 'j2', title: 'Güvenlik Görevlisi', salary: 25000, type: 'normal' },
  { id: 'j3', title: 'Vought Stajyeri', salary: 20000, type: 'vought' },
  { id: 'j4', title: 'Sokak Torbacısı', salary: 40000, type: 'criminal', requiredFame: 0 },
  { id: 'j5', title: 'Vought PR Uzmanı', salary: 80000, type: 'vought', requiredFame: 30 },
  { id: 'j6', title: 'Yerel Kahraman', salary: 100000, type: 'supe', requiredPower: 40, requiredFame: 40 },
  { id: 'j7', title: 'Tetikçi', salary: 150000, type: 'criminal', requiredPower: 30 },
  { id: 'j8', title: 'The Seven Üyesi', salary: 1000000, type: 'supe', requiredPower: 80, requiredFame: 80 },
];

export const BUYABLE_ASSETS: Asset[] = [
  { id: 'a1', name: 'Döküntü Daire', type: 'house', value: 50000, maintenanceCost: 500 },
  { id: 'a2', name: 'Lüks Rezidans', type: 'house', value: 500000, maintenanceCost: 5000 },
  { id: 'a3', name: 'Vought Kulesi Penthouse', type: 'house', value: 5000000, maintenanceCost: 50000 },
  { id: 'a4', name: 'İkinci El Sedan', type: 'vehicle', value: 20000, maintenanceCost: 200 },
  { id: 'a5', name: 'Zırhlı SUV', type: 'vehicle', value: 150000, maintenanceCost: 1500 },
];

export const COMPOUND_V_PRICES = {
  temporary: 25000,
  permanent: 500000,
  cleanse: 1000000,
};

export const POWER_TEMPLATES: Omit<Power, 'id'>[] = [
  { name: 'Lazer Gözler', description: 'Gözlerinden ölümcül ısı ışınları atarsın.', type: 'elemental', strength_level: 85, control_level: 50, visibility: 'hidden', side_effects: ['Gözlerde sürekli yanma hissi', 'Güneş gözlüğü takma zorunluluğu'], abilities: ['Çelik eritme', 'İnsanları ikiye bölme'] },
  { name: 'Devasa Mutasyona Uğramış Kol', description: 'Sağ kolun devasa, kaslı ve iğrenç bir görünüme sahip.', type: 'mutation', strength_level: 90, control_level: 30, visibility: 'public', side_effects: ['Kıyafet bulamama', 'İnsanların korkması', 'Denge kaybı'], abilities: ['Araba fırlatma', 'Duvar yıkma'] },
  { name: 'Asit Terlemesi', description: 'Terin metali bile eritebilen bir aside dönüşür.', type: 'weird', strength_level: 60, control_level: 20, visibility: 'public', side_effects: ['Sürekli kötü koku', 'Dokunduğun eşyaları eritme', 'Sosyal izolasyon'], abilities: ['Kilitleri eritme', 'Yakın dövüşte ölümcül hasar'] },
  { name: 'Zihin Okuma', description: 'İnsanların düşüncelerini duyabilirsin.', type: 'mental', strength_level: 40, control_level: 40, visibility: 'hidden', side_effects: ['Şiddetli baş ağrısı', 'Paranoya', 'Kalabalıkta delirme hissi'], abilities: ['Sırları öğrenme', 'Yalanları yakalama'] },
  { name: 'Süper Dayanıklılık', description: 'Derin kurşun geçirmez ve kemiklerin kırılmaz.', type: 'physical', strength_level: 85, control_level: 90, visibility: 'hidden', side_effects: ['İğne yapılamaması (tıbbi müdahale zorluğu)', 'Ağrı hissetmeme (yaralanmaları fark edememe)'], abilities: ['Patlamalardan sağ çıkma', 'Mermilere direnme'] },
  { name: 'Kontrolsüz Işınlanma', description: 'Stres altındayken rastgele yerlere ışınlanırsın.', type: 'strange', strength_level: 70, control_level: 10, visibility: 'hidden', side_effects: ['Işınlanırken kıyafetlerin geride kalması', 'Mide bulantısı', 'Duvarın içine ışınlanma korkusu'], abilities: ['Tehlikeden anında kaçış'] },
  { name: 'Patlayıcı Hapşırma', description: 'Hapşırdığında bir el bombası gücünde şok dalgası yaratırsın.', type: 'weird', strength_level: 75, control_level: 5, visibility: 'hidden', side_effects: ['Alerji mevsiminde ölüm tehlikesi', 'Sürekli burun kaşıntısı'], abilities: ['Kapıları patlatma', 'Düşmanları uçurma'] },
  { name: 'Elektrikli Tükürük', description: 'Tükürüğün yüksek voltajlı elektrik taşır.', type: 'elemental', strength_level: 50, control_level: 60, visibility: 'hidden', side_effects: ['Yanlışlıkla kendini çarpma', 'Öpüşememe'], abilities: ['Elektronikleri kısa devre yaptırma', 'Düşmanı felç etme'] },
  { name: 'Kemik Zırh', description: 'Derini delip çıkan sivri kemiklerle kaplanabilirsin.', type: 'mutation', strength_level: 70, control_level: 40, visibility: 'public', side_effects: ['Aşırı acı verici dönüşüm', 'Korkunç görünüm'], abilities: ['Yakın dövüşte hasar yansıtma', 'Ölümcül darbeler'] },
  { name: 'Kan Manipülasyonu', description: 'Kendi kanını silah olarak kullanabilirsin.', type: 'strange', strength_level: 80, control_level: 30, visibility: 'hidden', side_effects: ['Sürekli anemi (kansızlık)', 'Halsizlik'], abilities: ['Kandan bıçak yapma', 'Kan fırlatma'] }
];
